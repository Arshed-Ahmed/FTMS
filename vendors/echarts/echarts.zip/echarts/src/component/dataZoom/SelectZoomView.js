define(function (require) {

    return require('./DataZoomView').extend({

        type: 'dataZoom.select'

    });

});